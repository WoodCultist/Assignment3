using UnityEngine;

public class DoorTest : MonoBehaviour
{
    public GameObject player;
    private new Animation animation;
    public string[] animationNames;
    private bool isOpen = false;
    // Start is called before the first frame update
    void Start()
    {
        animation = GetComponent<Animation>();
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown("f") && !isOpen)
            if (Vector3.Distance(player.transform.position, gameObject.transform.position) <= 3.0f)
            {
                isOpen = true;
                animation.Play(animationNames[0]);
            }
        if (isOpen && Vector3.Distance(player.transform.position, gameObject.transform.position) >= 5.0f)
        {
            isOpen = false;
            animation.Play(animationNames[1]);
        }
    }
}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AnimalActivities : MonoBehaviour
{
    Vector3 targetPos = new Vector3();
    public float chillMax;
    bool isChilling = true;

    public float[] limit = new float[4];

    private float adjRotSpeed;
    private Quaternion targetRotation;

    // Update is called once per frame
    void Update()
    {
        if (isChilling)
        {
            targetPos = identifyTarget();
            isChilling = false;
        }
        else
        {
            if (Vector3.Distance(transform.position, targetPos) > 0.03f)
            {
                transform.position = Vector3.MoveTowards(transform.position, targetPos, 2.0f * Time.deltaTime);

                targetRotation = Quaternion.LookRotation(targetPos - transform.position);
                adjRotSpeed = Mathf.Min(5.0f * Time.deltaTime, 1);
                transform.rotation = Quaternion.Lerp(transform.rotation, targetRotation, adjRotSpeed);
            }
            else isChilling = true;
        }
    }

    Vector3 identifyTarget()
    {
        return new Vector3(Random.Range(limit[0], limit[1]), 0f, Random.Range(limit[2], limit[3]));
    }
}

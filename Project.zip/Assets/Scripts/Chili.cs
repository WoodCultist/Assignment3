using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Chili : MonoBehaviour
{
    GameManager gameManager;
    ParticleSystem fire;
    // Start is called before the first frame update
    void Start()
    {
        gameManager = GameObject.FindGameObjectWithTag("GameManager").GetComponent<GameManager>();
        fire = gameObject.GetComponent<ParticleSystem>();
    }

    // Update is called once per frame
    void Update()
    {
        if (gameManager.redHotChiliPepper == true)
        {
            if (Input.GetKeyDown("f")) fire.Play();
            else if (Input.GetKeyUp("f")) fire.Stop();
        }
    }
}

using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using UnityEngine;
using UnityEngine.UI;

public class GameManager : MonoBehaviour
{
    public GameObject player;
    public Text pickupText;

    //Pickup and Level Completion Logic
    public int currentPickups = 0;
    public int maxPickups = 5;
    public bool levelComplete = false;

    //Audio Proximity Logic
    public AudioSource[] audioSources;
    public float audioProximity = 5.0f;

    //Power Up Display Logic
    public bool thirdScene;
    public bool redHotChiliPepper;
    public bool sanAndreas;

    // Update is called once per frame
    void Update()
    {
        LevelCompleteCheck();
        UpdateGUI();
        PlayAudioSamples();
    }

    private void LevelCompleteCheck()
    {
        if (currentPickups >= maxPickups) levelComplete = true;
    }

    private void UpdateGUI()
    {
        if (thirdScene)
        {
            pickupText.text = "Pickups: " + currentPickups + "/" + maxPickups + (redHotChiliPepper ? "\nPress 'F' to activate chili mode" : null) + (sanAndreas ? "\nWalk to activate GTA San Andreas mode" : null);
        }
        else pickupText.text = "Pickups: " + currentPickups + "/" + maxPickups;
    }

    private void PlayAudioSamples()
    {
        for (int i = 0; i < audioSources.Length; i++)
        {
            try
            {
                if (Vector3.Distance(player.transform.position, audioSources[i].transform.position) <= audioProximity)
                    if (!audioSources[i].isPlaying) audioSources[i].Play();
            } catch { }
        }
    }
}

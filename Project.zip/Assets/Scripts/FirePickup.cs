using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FirePickup : MonoBehaviour
{
    public GameObject playerFire;

    private void OnTriggerEnter(Collider otherObject)
    {
        if (otherObject.transform.tag == "Fire")
            Instantiate(playerFire, gameObject.transform);

    }
}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GoForLaunch : MonoBehaviour
{
    public GameObject afterburn;
    bool launched = false;
    float timer;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        //if (playerCamera.GetComponent<CameraMovement>().cameraIndex == 4 && Vector3.Distance(node.transform.position, playerCamera.transform.position) < 0.1f) goForLaunch = true;
        if (GetComponent<AudioSource>().isPlaying)
        {
            if (!launched)
            {
                timer = timer + Time.deltaTime;
                if (timer >= 4.967f)
                {
                    Instantiate(afterburn, gameObject.transform);
                    launched = true;
                    timer = 0;
                }
            }
        }
        else if (launched)
        {
            launched = false;
            timer = 0;
        }
    }
}

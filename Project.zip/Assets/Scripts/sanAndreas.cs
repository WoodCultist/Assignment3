using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class sanAndreas : MonoBehaviour
{
    private PlayerMovement playerMovement;
    private bool swaggerMode;
    private AudioSource audioSource;

    // Start is called before the first frame update
    void Start()
    {
        playerMovement = gameObject.GetComponent<PlayerMovement>();
        audioSource = gameObject.GetComponent<AudioSource>();
    }

    // Update is called once per frame
    void LateUpdate()
    {
        if (swaggerMode)
        {
            if (Input.GetKey("w") && !Input.GetKey(KeyCode.LeftShift) && playerMovement.anim.GetCurrentAnimatorStateInfo(1).IsName("Waving") == false)
            {
                if(!audioSource.isPlaying) audioSource.Play();
            }
            else
            {
                if(audioSource.isPlaying) audioSource.Pause();
            }
        }
    }
    private void OnTriggerEnter(Collider otherObject)
    {
        if (otherObject.transform.tag == "San Andreas")
            swaggerMode = true;
    }
}
